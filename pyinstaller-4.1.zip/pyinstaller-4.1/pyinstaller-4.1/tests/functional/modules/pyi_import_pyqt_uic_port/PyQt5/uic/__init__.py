print('this is my faked PyQt5.uic package')
__pyinstaller_fake_module_marker__ = '__pyinstaller_fake_module_marker__'
