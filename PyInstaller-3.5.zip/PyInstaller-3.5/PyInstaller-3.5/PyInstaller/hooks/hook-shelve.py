#-----------------------------------------------------------------------------
# Copyright (c) 2013-2019, PyInstaller Development Team.
#
# Distributed under the terms of the GNU General Public License with exception
# for distributing bootloader.
#
# The full license is in the file COPYING.txt, distributed with this software.
#-----------------------------------------------------------------------------
# Tested on Windows 7 x64 With Pyhton 3.5

hiddenimports = ["dbm.ndbm", "dbm.dumb", "dbm.gnu"]
